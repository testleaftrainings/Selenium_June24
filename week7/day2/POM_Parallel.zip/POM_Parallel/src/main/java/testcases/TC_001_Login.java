package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC_001_Login extends ProjectSpecificMethod{

	@Test
	public void runLogin() {
		System.out.println("driver value in testcase class "+driver);
		LoginPage lp  = new LoginPage(driver);
		lp.enterUsername().enterPassword().clickLogin().verifyTitle();
		
	}
	
}
