package pages;

import base.ProjectSpecificMethod;

public class FindLeadsPage extends ProjectSpecificMethod{

	public FindLeadsPage clickPhTab() {
		
		return this;
	}
	
	
	public FindLeadsPage enterPhno() {
		
		return this;
	}
	
	
	public FindLeadsPage clickFindLeadBtn() {
	
		return this;
	}
	
	public ViewLeadPage clickFirstLeadId() {
		
		return new ViewLeadPage(driver);
	}
	
	
}
