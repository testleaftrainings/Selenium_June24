package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeMethod;

import base.ProjectSpecificMethod;

public class LoginPage extends ProjectSpecificMethod{

	public LoginPage(RemoteWebDriver driver) {
		// varibale = value;
		this.driver = driver;
	}

	public LoginPage enterUsername() {
		System.out.println("driver value in pages class "+driver);
		driver.findElement(By.id("username")).sendKeys("demosalesmanager");
	
		return this;
	}
	
	public LoginPage enterPassword() {
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		return this;
	}
	
	public WelcomePage clickLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage(driver);
	}
	
	

	
	
}
