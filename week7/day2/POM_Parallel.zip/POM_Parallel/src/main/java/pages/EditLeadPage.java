package pages;

import base.ProjectSpecificMethod;

public class EditLeadPage extends ProjectSpecificMethod {

	
	public EditLeadPage updateCompanyName() {
		
		
		return this;
	}
	
	public ViewLeadPage clickUpdateBtn() {
		
		return new ViewLeadPage(driver);
	}
	
}
