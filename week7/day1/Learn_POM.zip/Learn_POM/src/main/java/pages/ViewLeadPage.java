package pages;

public class ViewLeadPage {

	public ViewLeadPage getLeadID() {
		
		return this;
	}
	
	public EditLeadPage clickEditBtn() {
		
		return new EditLeadPage();
	}
	
	public void clickDeleteBtn() {
		
	}
	
	
	
}
