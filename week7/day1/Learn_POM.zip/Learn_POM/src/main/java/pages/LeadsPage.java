package pages;

public class LeadsPage {

	
	public CreateLeadPage clickCreateLeadLink() {
		
		return new CreateLeadPage();
	}
	
	public FindLeadsPage clickFindLeadLink() {
		
		return new FindLeadsPage();
	}
	
	public void clickMergeLeadLink() {
		
	}
	
	
}
