package pages;

public class CreateLeadPage {

	
	public CreateLeadPage enterCompanyName() {
		
		return this;
	}
	
	public CreateLeadPage enterFirstName() {
		
		return this;
	}
	
	public CreateLeadPage enterLastName() {
		
		return this;
	}
	
	public CreateLeadPage enterPhno() {
		
		return this;
	}
	
	public ViewLeadPage clickCreateLeadBtn() {
	
		
		return new ViewLeadPage();
	}
	
}
