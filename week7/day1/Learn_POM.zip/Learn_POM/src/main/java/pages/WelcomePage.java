package pages;

import base.ProjectSpecificMethod;

public class WelcomePage extends ProjectSpecificMethod{

	public WelcomePage verifyTitle() {
		System.out.println(driver.getTitle());
		return this;
	}
	
	public HomePage clickCrmsfa() {
		
		return new HomePage();
	}
	
	public LoginPage clickLogout() {
	
		return new LoginPage();
	}
	
	
}
