package pages;

public class HomePage {

	public LeadsPage clickLeadsTab() {
		
		return new LeadsPage(); 
	}
	
	public void clickAccountsTab() {
		
	}
	
	public void clickContactsTab() {
		
	}
	
	
}
