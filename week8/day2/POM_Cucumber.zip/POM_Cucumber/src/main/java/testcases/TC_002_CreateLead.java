package testcases;

import java.io.IOException;

import org.openqa.selenium.WebDriverException;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC_002_CreateLead extends ProjectSpecificMethod {

	@Test
	public void runCreateLead() throws WebDriverException, IOException {
		
		new LoginPage()
		.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickCrmsfa()
		.clickLeadsTab()
		.clickCreateLeadLink()
		.enterCompanyName()
		.enterFirstName()
		.enterLastName()
		.clickCreateLeadBtn()
		.getLeadID();
		
	}
	
}
