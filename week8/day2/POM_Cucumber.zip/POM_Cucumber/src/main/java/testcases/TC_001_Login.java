package testcases;

import java.io.IOException;

import org.openqa.selenium.WebDriverException;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC_001_Login extends ProjectSpecificMethod{

	@Test
	public void runLogin() throws WebDriverException, IOException {
		LoginPage lp  = new LoginPage();
		lp.enterUsername().enterPassword().clickLogin();
		
	}
	
	@BeforeTest
	public void setData() {
		testcaseName ="TC_001_Login";
		testcaseDesc = "Login testcase with valid credentials";
		authorName = "Gokul";
		categoryName = "Regression";
	}
}
