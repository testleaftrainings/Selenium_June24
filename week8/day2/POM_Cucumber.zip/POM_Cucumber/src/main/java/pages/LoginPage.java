package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriverException;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod{

	@Given ("Enter the username")
	public LoginPage enterUsername() throws WebDriverException, IOException {
		
		try {
			driver.findElement(By.id("username")).sendKeys(prop.getProperty("username"));
//			FileUtils.copyFile(driver.getScreenshotAs(OutputType.FILE), new File("./snaps/img1.png"));
//			test.pass("username entered successfully", MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img1.png").build());
			
			reportStep("pass", "username entered successfully");
			
		} catch (Exception e) {
			
//				FileUtils.copyFile(driver.getScreenshotAs(OutputType.FILE), new File("./snaps/img1.png"));
//				test.fail("unable to enter the username "+e, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img1.png").build());
			 reportStep("fail", "unable to enter the username "+e);
			
		}
		
		//dataType varibale = value
//		LoginPage lp = new LoginPage();
//		return lp;
		
//		return new LoginPage();
		
		return this;
	}
	
	@Given ("Enter the password")
	public LoginPage enterPassword() throws WebDriverException, IOException {
		try {
			driver.findElement(By.id("password")).sendKeys(prop.getProperty("password"));
//			FileUtils.copyFile(driver.getScreenshotAs(OutputType.FILE), new File("./snaps/img2.png"));
//			test.pass("password entered successfully", MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img2.png").build());
			reportStep("pass", "password entered successfully");
		} catch (Exception e) {
			
//				FileUtils.copyFile(driver.getScreenshotAs(OutputType.FILE), new File("./snaps/img2.png"));
//				test.fail("unable to enter the password "+e, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img2.png").build());
			reportStep("fail", "unable to enter the password "+e);
		}
		return this;
	}
	
	@When ("Click on login button")
	public WelcomePage clickLogin() throws IOException {
		try {
			driver.findElement(By.className("decorativeSubmit")).click();
			reportStep("pass", "Login button clicked Successfully");
		} catch (Exception e) {
			reportStep("fail", "Unable to login on the login button "+e);
		}
		return new WelcomePage();
	}
	
}
