package pages;

public class EditLeadPage {

	
	public EditLeadPage updateCompanyName() {
		
		
		return this;
	}
	
	public ViewLeadPage clickUpdateBtn() {
		
		return new ViewLeadPage();
	}
	
}
