package com.salesforce.pages;

import org.openqa.selenium.WebElement;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{

	
	public LoginPage enterUsername() {
		WebElement username = locateElement(Locators.ID, "username");
		clearAndType(username, "gokul.sekar@testleaf.com");
		reportStep("Username entered successfully", "pass");
		return this;
	}
	
	public LoginPage enterPassword() {
		
		clearAndType(locateElement(Locators.ID, "password"), "Leaf$321");
		reportStep("Password entered successfully", "pass");
		return this;
	}
	
	
	public HomePage clickLogin() {
		click(locateElement("Login"));
		reportStep("Login button clicked successfully ", "pass");
		return new HomePage();
	}
	
}
