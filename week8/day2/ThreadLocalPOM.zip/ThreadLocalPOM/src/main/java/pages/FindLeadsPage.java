package pages;

public class FindLeadsPage {

	public FindLeadsPage clickPhTab() {
		
		return this;
	}
	
	
	public FindLeadsPage enterPhno() {
		
		return this;
	}
	
	
	public FindLeadsPage clickFindLeadBtn() {
	
		return this;
	}
	
	public ViewLeadPage clickFirstLeadId() {
		
		return new ViewLeadPage();
	}
	
	
}
