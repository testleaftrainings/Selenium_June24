package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Then;

public class WelcomePage extends ProjectSpecificMethod{

	@Then ("Verify the login is successful")
	public WelcomePage verifyTitle() {
		System.out.println(getDriver().getTitle());
		return this;
	}
	
	public HomePage clickCrmsfa() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new HomePage();
	}
	
	public LoginPage clickLogout() {
	
		return new LoginPage();
	}
	
	
}
