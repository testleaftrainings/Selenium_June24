package testcases;

import java.io.IOException;

import org.openqa.selenium.WebDriverException;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC_002_CreateLead extends ProjectSpecificMethod {

	@Test(dataProvider = "fetchData")
	public void runCreateLead(String cname, String fname, String lname, String phno) throws WebDriverException, IOException {
		
		new LoginPage()
		.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickCrmsfa()
		.clickLeadsTab()
		.clickCreateLeadLink()
		.enterCompanyName(cname)
		.enterFirstName(fname)
		.enterLastName(lname)
		.clickCreateLeadBtn()
		.getLeadID();
		
	}
	
	@BeforeTest
	public void setData() {
		testcaseName ="TC_002_CreateLead";
		testcaseDesc = "Create Lead with valid Test data";
		authorName = "Gokul";
		categoryName = "Regression";
		excelFilename = "Create";
	}
	
}
