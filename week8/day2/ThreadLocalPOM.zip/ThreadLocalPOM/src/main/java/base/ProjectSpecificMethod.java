package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.DataLibrary;

public class ProjectSpecificMethod extends AbstractTestNGCucumberTests{

//	public static RemoteWebDriver driver;
	public static Properties prop;
	public static ExtentReports extent;
	public static ExtentTest test;
	public String testcaseName, testcaseDesc, authorName, categoryName, excelFilename;
	
	private static final ThreadLocal<RemoteWebDriver> rd = new ThreadLocal<RemoteWebDriver>();
	
	private static final ThreadLocal<ExtentTest> parentTest = new ThreadLocal<ExtentTest>();
	private static final ThreadLocal<ExtentTest> childNode = new ThreadLocal<ExtentTest>();
	private static final ThreadLocal<String> testName = new ThreadLocal<String>();
	
	@Parameters({"lang"})
	@BeforeMethod
	public void preCondition(String lang) throws IOException {
		
		FileInputStream fis = new FileInputStream("./src/main/resources/"+lang+".properties");
		
		prop = new Properties();
		
		prop.load(fis);
		setNode();
		try {
//			getDriver() = new ChromeDriver();
			setDriver();
			getNode().info("Browser launched successfully");
		} catch (Exception e) {
			getNode().fail("Unable to launch the browser "+e);
		}
		try {
			getDriver().get("http://leaftaps.com/opentaps/");
			getNode().info("url loaded successfully");
		} catch (Exception e) {
			getNode().fail("failed to load the url");
		}
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
	}
	
	@AfterMethod
	public void postCondition() {
		getDriver().close();
	}
	
	public void setDriver() {
		rd.set(new ChromeDriver());
	}
	
	public RemoteWebDriver getDriver() {
		return rd.get();
	}
	
	
	//--------------Start report-------------------------
	
	@BeforeSuite
	public void startReport() {
		//Step1: Set the report path
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");
		// To maintain history of the report
		reporter.setAppendExisting(true);
		
		//Step2: Create obj for ExtentReports
		extent = new ExtentReports();
		
		//Step3: Attach the report the path
		extent.attachReporter(reporter);

	}
	
	//--------------Create testcase and assign testcase information--------------------------

	@BeforeClass
	public void setReportDetails() {
		//Step4: create report for the testcase
		test = extent.createTest(testcaseName, testcaseDesc);
		
		//Step5: add information for the testcase
		setTest();
		setTestname();
		getTest().assignAuthor(authorName);
		getTest().assignCategory(categoryName);
		
	}
	
	public void setTest() {
		parentTest.set(test);
	}
	
	public ExtentTest getTest() {
		return parentTest.get();
	}
	
	
	public void setTestname() {
		testName.set(testcaseName);
	}
	
	public String getTestname() {
		return testName.get();
	}
	
	public void setNode() {
		ExtentTest node = getTest().createNode(getTestname());
		childNode.set(node);
	}
	
	public ExtentTest getNode() {
		return childNode.get();
	}
	
	
	//---------take snap----------------
	
	public int takeSnap() throws IOException {
		int randomNumber = (int) ((Math.random())*99999);
		File src = getDriver().getScreenshotAs(OutputType.FILE);
		File desc = new File("./Snaps/img"+randomNumber+".png");
		FileUtils.copyFile(src, desc);
		
		return randomNumber;
	}
	
	//----------------------report step----------------------
	public void reportStep(String status, String desc) throws IOException {
		
		if(status.equalsIgnoreCase("pass")) {
			getNode().pass(desc, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
		}else if(status.equalsIgnoreCase("fail")) {
			getNode().fail(desc, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
		}
		
	}
	
	
	
	
	
	//_-------------Close the report----------------
	@AfterSuite
	public void endReport() {
		extent.flush();
	}
	
	
	//---------------DAta provider
	
	@DataProvider(name = "fetchData")
	public String[][] sendData() throws IOException {
	
		return DataLibrary.readExcelData(excelFilename);
	}
	
	
	
	
	
}
