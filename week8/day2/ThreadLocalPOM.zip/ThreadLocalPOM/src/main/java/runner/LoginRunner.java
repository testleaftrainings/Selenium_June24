package runner;

import org.testng.annotations.BeforeTest;

import base.ProjectSpecificMethod;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = {"src/main/java/features"}, glue ="pages")
public class LoginRunner extends ProjectSpecificMethod{

	
	@BeforeTest
	public void setData() {
		testcaseName ="TC_001_Login";
		testcaseDesc = "Login testcase with valid credentials";
		authorName = "Gokul";
		categoryName = "Regression";
	}
	
}
