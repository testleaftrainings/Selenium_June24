package runner;

import org.testng.annotations.BeforeTest;

import base.ProjectSpecificMethod;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = {"src/main/java/features"}, glue ="pages")
public class LoginRunner2 extends ProjectSpecificMethod{

	
	@BeforeTest
	public void setData() {
		testcaseName ="TC_002_Login";
		testcaseDesc = "Login testcase with valid credentials";
		authorName = "Gokul";
		categoryName = "functional";
	}
	
}
