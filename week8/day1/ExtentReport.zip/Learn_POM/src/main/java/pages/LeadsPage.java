package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;

public class LeadsPage extends ProjectSpecificMethod{

	
	public CreateLeadPage clickCreateLeadLink() {
		driver.findElement(By.linkText(prop.getProperty("createLeadLink"))).click();
		return new CreateLeadPage();
	}
	
	public FindLeadsPage clickFindLeadLink() {
		
		return new FindLeadsPage();
	}
	
	public void clickMergeLeadLink() {
		
	}
	
	
}
