package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;

public class ViewLeadPage  extends ProjectSpecificMethod{

	public ViewLeadPage getLeadID() {
		String leadId = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		System.out.println("Lead Id "+leadId);
		return this;
	}
	
	public EditLeadPage clickEditBtn() {
		
		return new EditLeadPage();
	}
	
	public void clickDeleteBtn() {
		
	}
	
	
	
}
