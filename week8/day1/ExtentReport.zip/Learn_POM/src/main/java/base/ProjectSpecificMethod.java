package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ProjectSpecificMethod {

	public static RemoteWebDriver driver;
	public static Properties prop;
	public ExtentReports extent;
	public static ExtentTest test;
	public String testcaseName, testcaseDesc, authorName, categoryName;
	@Parameters({"lang"})
	@BeforeMethod
	public void preCondition(String lang) throws IOException {
		
		FileInputStream fis = new FileInputStream("./src/main/resources/"+lang+".properties");
		
		prop = new Properties();
		
		prop.load(fis);
		
		try {
			driver = new ChromeDriver();
			test.info("Browser launched successfully");
		} catch (Exception e) {
			test.fail("Unable to launch the browser "+e);
		}
		try {
			driver.get("http://leaftaps.com/opentaps/");
			test.info("url loaded successfully");
		} catch (Exception e) {
			test.fail("failed to load the url");
		}
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
	}
	
	@AfterMethod
	public void postCondition() {
		driver.close();
	}
	//--------------Start report-------------------------
	
	@BeforeSuite
	public void startReport() {
		//Step1: Set the report path
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");
		// To maintain history of the report
		reporter.setAppendExisting(true);
		
		//Step2: Create obj for ExtentReports
		extent = new ExtentReports();
		
		//Step3: Attach the report the path
		extent.attachReporter(reporter);

	}
	
	//--------------Create testcase and assign testcase information--------------------------

	@BeforeClass
	public void setReportDetails() {
		//Step4: create report for the testcase
		test = extent.createTest(testcaseName, testcaseDesc);
		
		//Step5: add information for the testcase
		test.assignAuthor(authorName);
		test.assignCategory(categoryName);
	}
	//---------take snap----------------
	
	public int takeSnap() throws IOException {
		int randomNumber = (int) ((Math.random())*99999);
		File src = driver.getScreenshotAs(OutputType.FILE);
		File desc = new File("./Snaps/img"+randomNumber+".png");
		FileUtils.copyFile(src, desc);
		
		return randomNumber;
	}
	
	//----------------------report step----------------------
	public void reportStep(String status, String desc) throws IOException {
		
		if(status.equalsIgnoreCase("pass")) {
			test.pass(desc, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
		}else if(status.equalsIgnoreCase("fail")) {
			test.fail(desc, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
		}
		
	}
	
	
	
	
	
	//_-------------Close the report----------------
	@AfterSuite
	public void endReport() {
		extent.flush();
	}
	
	
	
	
	
}
